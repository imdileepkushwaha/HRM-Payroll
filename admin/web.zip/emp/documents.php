<?php
require __DIR__ . '/includes/header.php';
require_once __DIR__ . '/../includes/employee_document_helper.php';

$emp_id = $employee['emp_id'];
$approved_docs = get_employee_documents($conn, $emp_id, true);
$other_docs = get_employee_documents_by_type($conn, $emp_id, 'other', true);
$request_history = get_employee_document_requests($conn, $emp_id, 15);
$pending_count = count_employee_pending_document_requests($conn, $emp_id);
$aadhar_progress = employee_aadhar_completion($conn, $emp_id);
$marksheet_progress = employee_marksheet_completion($conn, $emp_id);
$pan_status = employee_document_status_for_slot($conn, $emp_id, 'pan', 'main');

$aadhar_subtypes = employee_document_aadhar_subtypes();
$marksheet_subtypes = employee_document_marksheet_subtypes();
$other_subtypes = employee_document_other_subtypes();

function emp_doc_status_badge_class(string $status): string
{
    return match ($status) {
        'approved' => 'is-approved',
        'pending' => 'is-pending',
        default => 'is-missing',
    };
}

function emp_doc_render_slot_upload($conn, string $emp_id, string $doc_type, string $doc_subtype, string $slot_label, string $input_id): void
{
    $status = employee_document_status_for_slot($conn, $emp_id, $doc_type, $doc_subtype);
    $approved = $status['document'] ?? null;
    $can_upload = $status['status'] !== 'pending';
    $badge_class = emp_doc_status_badge_class($status['status']);
    ?>
    <div class="emp-doc-slot emp-doc-slot-<?php echo htmlspecialchars($status['status']); ?>">
        <div class="emp-doc-slot-head">
            <div class="emp-doc-slot-title">
                <strong><?php echo htmlspecialchars($slot_label); ?></strong>
                <span class="emp-doc-status-badge <?php echo htmlspecialchars($badge_class); ?>"><?php echo htmlspecialchars($status['label']); ?></span>
            </div>
            <?php if ($approved): ?>
                <div class="emp-doc-slot-approved">
                    <span><?php echo date('d M Y', strtotime($approved['approved_at'])); ?> · <?php echo htmlspecialchars(format_employee_document_size((int) $approved['file_size'])); ?></span>
                    <a href="document_download.php?doc_id=<?php echo (int) $approved['id']; ?>" class="btn btn-outline btn-sm" target="_blank" rel="noopener">View</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!$can_upload): ?>
            <div class="emp-doc-wait-banner emp-doc-wait-banner-compact">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <p>Pending admin review</p>
            </div>
        <?php else: ?>
            <form method="POST" action="document_upload_save.php" enctype="multipart/form-data" class="emp-doc-slot-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="doc_type" value="<?php echo htmlspecialchars($doc_type); ?>">
                <input type="hidden" name="doc_subtype" value="<?php echo htmlspecialchars($doc_subtype); ?>">
                <label class="emp-doc-file-zone emp-doc-file-zone-compact" for="<?php echo htmlspecialchars($input_id); ?>">
                    <input type="file" name="document_file" id="<?php echo htmlspecialchars($input_id); ?>" class="emp-doc-file-input" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" required>
                    <span class="emp-doc-file-zone-ui">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <strong class="emp-doc-file-label"><?php echo $approved ? 'Replace file' : 'Upload PDF or image'; ?></strong>
                        <span class="emp-doc-file-name">Max 5 MB</span>
                    </span>
                </label>
                <button type="submit" class="emp-doc-submit-btn emp-doc-submit-btn-sm"><?php echo $approved ? 'Submit replacement' : 'Submit for approval'; ?></button>
            </form>
        <?php endif; ?>
    </div>
    <?php
}
?>
<div class="emp-page emp-page-documents">
    <?php require __DIR__ . '/includes/flash.php'; ?>

    <div class="emp-page-hero emp-page-hero-docs">
        <div class="emp-page-hero-main">
            <p class="page-eyebrow">Documents</p>
            <h2 class="emp-page-hero-title">Upload & verify your documents</h2>
            <p>Upload Aadhar front &amp; back, PAN, education certificates from 10th to post graduation, and supporting letters.</p>
        </div>
        <?php if ($pending_count > 0): ?>
            <span class="emp-doc-pending-chip"><?php echo (int) $pending_count; ?> pending review</span>
        <?php endif; ?>
    </div>

    <div class="emp-doc-stats">
        <div class="emp-doc-stat emp-doc-stat-approved">
            <span class="emp-doc-stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            </span>
            <div>
                <span class="emp-doc-stat-label">Approved</span>
                <strong class="emp-doc-stat-value"><?php echo count($approved_docs); ?></strong>
            </div>
        </div>
        <div class="emp-doc-stat emp-doc-stat-pending">
            <span class="emp-doc-stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </span>
            <div>
                <span class="emp-doc-stat-label">Pending review</span>
                <strong class="emp-doc-stat-value"><?php echo (int) $pending_count; ?></strong>
            </div>
        </div>
        <div class="emp-doc-stat emp-doc-stat-verified">
            <span class="emp-doc-stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2"/></svg>
            </span>
            <div>
                <span class="emp-doc-stat-label">Aadhar complete</span>
                <strong class="emp-doc-stat-value"><?php echo (int) $aadhar_progress['approved']; ?>/<?php echo (int) $aadhar_progress['total']; ?></strong>
                <small>Front + back</small>
            </div>
        </div>
        <div class="emp-doc-stat emp-doc-stat-format">
            <span class="emp-doc-stat-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c0 1 2 3 6 3s6-2 6-3v-5"/></svg>
            </span>
            <div>
                <span class="emp-doc-stat-label">Education docs</span>
                <strong class="emp-doc-stat-value"><?php echo (int) $marksheet_progress['approved']; ?>/<?php echo (int) $marksheet_progress['total']; ?></strong>
                <small>10th to PG</small>
            </div>
        </div>
    </div>

    <div class="emp-doc-panel">
        <div class="emp-doc-toolbar">
            <div class="emp-doc-policy-chips">
                <span class="emp-doc-policy-chip">Admin verification required</span>
                <span class="emp-doc-policy-chip">PDF · JPG · PNG · Max 5 MB</span>
            </div>
            <a href="details.php" class="btn btn-outline btn-sm">My profile details</a>
        </div>

        <div class="emp-doc-sections">
            <section class="emp-doc-section emp-doc-section-aadhar">
                <header class="emp-doc-section-head">
                    <div>
                        <h3>Aadhar card</h3>
                        <p>Upload clear scans of both front and back sides.</p>
                    </div>
                    <span class="emp-doc-section-progress <?php echo $aadhar_progress['complete'] ? 'is-complete' : ''; ?>">
                        <?php echo (int) $aadhar_progress['approved']; ?>/<?php echo (int) $aadhar_progress['total']; ?> verified
                    </span>
                </header>
                <div class="emp-doc-slot-grid emp-doc-slot-grid-2">
                    <?php emp_doc_render_slot_upload($conn, $emp_id, 'aadhar', 'front', $aadhar_subtypes['front'], 'aadhar_front'); ?>
                    <?php emp_doc_render_slot_upload($conn, $emp_id, 'aadhar', 'back', $aadhar_subtypes['back'], 'aadhar_back'); ?>
                </div>
            </section>

            <section class="emp-doc-section emp-doc-section-pan">
                <header class="emp-doc-section-head">
                    <div>
                        <h3>PAN card</h3>
                        <p>Upload a clear photo or PDF of your PAN card.</p>
                    </div>
                    <span class="emp-doc-status-badge <?php echo htmlspecialchars(emp_doc_status_badge_class($pan_status['status'])); ?>">
                        <?php echo htmlspecialchars($pan_status['label']); ?>
                    </span>
                </header>
                <?php emp_doc_render_slot_upload($conn, $emp_id, 'pan', 'main', 'PAN card', 'pan_main'); ?>
            </section>

            <section class="emp-doc-section emp-doc-section-education">
                <header class="emp-doc-section-head">
                    <div>
                        <h3>Education certificates</h3>
                        <p>Upload marksheets or degree certificates from 10th class through post graduation.</p>
                    </div>
                    <span class="emp-doc-section-progress">
                        <?php echo (int) $marksheet_progress['approved']; ?>/<?php echo (int) $marksheet_progress['total']; ?> uploaded
                    </span>
                </header>
                <div class="emp-doc-edu-ladder">
                    <?php
                    $step = 1;
                    foreach ($marksheet_subtypes as $subtype_key => $subtype_label):
                        $slot_status = employee_document_status_for_slot($conn, $emp_id, 'marksheet', $subtype_key);
                        ?>
                        <div class="emp-doc-edu-step emp-doc-edu-step-<?php echo htmlspecialchars($slot_status['status']); ?>">
                            <div class="emp-doc-edu-step-marker">
                                <span><?php echo (int) $step; ?></span>
                            </div>
                            <div class="emp-doc-edu-step-body">
                                <?php emp_doc_render_slot_upload($conn, $emp_id, 'marksheet', $subtype_key, $subtype_label, 'marksheet_' . $subtype_key); ?>
                            </div>
                        </div>
                        <?php
                        $step++;
                    endforeach;
                    ?>
                </div>
            </section>

            <section class="emp-doc-section emp-doc-section-other">
                <header class="emp-doc-section-head">
                    <div>
                        <h3>Other supporting documents</h3>
                        <p>Add experience letters, relieving letters, salary slips, offer letters and more. You can upload multiple documents.</p>
                    </div>
                    <span class="emp-doc-status-badge is-neutral"><?php echo count($other_docs); ?> approved</span>
                </header>

                <form method="POST" action="document_upload_save.php" enctype="multipart/form-data" class="emp-doc-other-upload-card" id="emp-doc-other-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="doc_type" value="other">
                    <div class="emp-doc-other-upload-grid">
                        <div class="form-group">
                            <label for="other_subtype">Document type</label>
                            <select name="doc_subtype" id="other_subtype" required>
                                <option value="">Select document type</option>
                                <?php foreach ($other_subtypes as $key => $label): ?>
                                    <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" id="other_label_wrap">
                            <label for="other_doc_label" id="other_label_text">Details (optional)</label>
                            <input type="text" name="doc_label" id="other_doc_label" maxlength="120" placeholder="e.g. ABC Pvt Ltd, Jan 2022">
                        </div>
                        <label class="emp-doc-file-zone emp-doc-file-zone-compact" for="other_file">
                            <input type="file" name="document_file" id="other_file" class="emp-doc-file-input" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" required>
                            <span class="emp-doc-file-zone-ui">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                <strong class="emp-doc-file-label">Choose PDF or image</strong>
                                <span class="emp-doc-file-name">Max 5 MB</span>
                            </span>
                        </label>
                    </div>
                    <button type="submit" class="emp-doc-submit-btn">Add document for approval</button>
                </form>

                <?php if ($other_docs !== []): ?>
                    <div class="emp-doc-other-library">
                        <h4>Your approved documents</h4>
                        <div class="emp-doc-other-grid">
                            <?php foreach ($other_docs as $doc): ?>
                                <div class="emp-doc-other-item">
                                    <div class="emp-doc-other-item-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                    </div>
                                    <div class="emp-doc-other-item-body">
                                        <span class="emp-doc-other-item-type"><?php echo htmlspecialchars(employee_document_subtype_label('other', $doc['doc_subtype'] ?? '')); ?></span>
                                        <strong><?php echo htmlspecialchars(employee_document_display_label($doc)); ?></strong>
                                        <span><?php echo date('d M Y', strtotime($doc['approved_at'])); ?> · <?php echo htmlspecialchars(format_employee_document_size((int) $doc['file_size'])); ?></span>
                                    </div>
                                    <a href="document_download.php?doc_id=<?php echo (int) $doc['id']; ?>" class="btn btn-outline btn-sm" target="_blank" rel="noopener">View</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php
                $pending_other = array_values(array_filter(
                    $request_history,
                    static fn($req) => ($req['request_status'] ?? '') === 'pending' && ($req['doc_type'] ?? '') === 'other'
                ));
                if ($pending_other !== []):
                    ?>
                    <div class="emp-doc-other-pending">
                        <h4>Pending other documents</h4>
                        <div class="emp-doc-other-grid">
                            <?php foreach ($pending_other as $req): ?>
                                <div class="emp-doc-other-item is-pending">
                                    <div class="emp-doc-other-item-body">
                                        <span class="emp-doc-other-item-type"><?php echo htmlspecialchars(employee_document_subtype_label('other', $req['doc_subtype'] ?? '')); ?></span>
                                        <strong><?php echo htmlspecialchars(employee_document_display_label($req)); ?></strong>
                                        <span>Submitted <?php echo date('d M Y', strtotime($req['created_at'])); ?></span>
                                    </div>
                                    <span class="emp-doc-status-badge is-pending">Pending</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <?php if ($request_history !== []): ?>
            <section class="emp-doc-history-section">
                <div class="emp-doc-history-head">
                    <h3>Upload history</h3>
                    <p>Track submissions, approvals and admin feedback.</p>
                </div>
                <div class="emp-doc-history-list">
                    <?php foreach ($request_history as $req):
                        $status = $req['request_status'] ?? '';
                        $approved_doc = $status === 'approved' ? get_employee_document_by_request_id($conn, (int) $req['id']) : null;
                        $view_url = null;
                        if ($status === 'pending') {
                            $view_url = 'document_download.php?request_id=' . (int) $req['id'];
                        } elseif ($approved_doc) {
                            $view_url = 'document_download.php?doc_id=' . (int) $approved_doc['id'];
                        }
                        ?>
                        <article class="emp-doc-history-row emp-doc-history-<?php echo htmlspecialchars($status); ?>">
                            <span class="emp-doc-history-dot" aria-hidden="true"></span>
                            <div class="emp-doc-history-main">
                                <div class="emp-doc-history-top">
                                    <strong><?php echo htmlspecialchars(employee_document_display_label($req)); ?></strong>
                                    <span class="emp-req-status emp-req-<?php echo htmlspecialchars($status); ?>"><?php echo htmlspecialchars(ucfirst($status)); ?></span>
                                </div>
                                <span class="emp-doc-history-meta"><?php echo date('d M Y, h:i A', strtotime($req['created_at'])); ?> · <?php echo htmlspecialchars(format_employee_document_size((int) $req['file_size'])); ?></span>
                                <?php if (!empty($req['review_note']) && $status !== 'pending'): ?>
                                    <p class="emp-doc-history-note">Admin: <?php echo htmlspecialchars($req['review_note']); ?></p>
                                <?php endif; ?>
                            </div>
                            <?php if ($view_url): ?>
                                <a href="<?php echo htmlspecialchars($view_url); ?>" class="btn btn-outline btn-sm" target="_blank" rel="noopener">View</a>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    </div>
</div>
<script>
(function () {
    document.querySelectorAll('.emp-doc-file-input').forEach(function (input) {
        input.addEventListener('change', function () {
            var zone = input.closest('.emp-doc-file-zone');
            if (!zone) {
                return;
            }
            var nameEl = zone.querySelector('.emp-doc-file-name');
            if (!nameEl) {
                return;
            }
            if (input.files && input.files[0]) {
                nameEl.textContent = input.files[0].name;
                zone.classList.add('has-file');
            } else {
                nameEl.textContent = 'Max 5 MB';
                zone.classList.remove('has-file');
            }
        });
    });

    var otherSubtype = document.getElementById('other_subtype');
    var otherLabelText = document.getElementById('other_label_text');
    var otherDocLabel = document.getElementById('other_doc_label');
    if (otherSubtype && otherLabelText && otherDocLabel) {
        otherSubtype.addEventListener('change', function () {
            var isCustom = otherSubtype.value === 'custom';
            if (isCustom) {
                otherLabelText.textContent = 'Document name';
                otherDocLabel.placeholder = 'e.g. Internship certificate';
                otherDocLabel.required = true;
            } else {
                otherLabelText.textContent = 'Details (optional)';
                otherDocLabel.placeholder = 'e.g. ABC Pvt Ltd, Jan 2022';
                otherDocLabel.required = false;
            }
            otherDocLabel.value = '';
        });
    }
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
