<?php

require_once __DIR__ . '/salary_helper.php';

function payroll_ext_table_exists($conn, $table)
{
    $table = $conn->real_escape_string($table);
    $r = $conn->query("SHOW TABLES LIKE '$table'");
    return $r && $r->num_rows > 0;
}

/* ---------- Payroll periods (approval / lock) ---------- */

function payroll_context_branch_id()
{
    if (function_exists('get_active_branch_id')) {
        $branch_id = get_active_branch_id();
        return $branch_id ?? 1;
    }
    return 1;
}

function get_payroll_period($conn, $year, $month, $branch_id = null)
{
    if ($branch_id === null) {
        $branch_id = payroll_context_branch_id();
    }
    $stmt = $conn->prepare('SELECT * FROM payroll_periods WHERE branch_id = ? AND period_year = ? AND period_month = ?');
    $stmt->bind_param('iii', $branch_id, $year, $month);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row) {
        return $row;
    }
    return [
        'period_year' => (int) $year,
        'period_month' => (int) $month,
        'status' => 'open',
        'approved_by' => null,
        'approved_at' => null,
        'locked_by' => null,
        'locked_at' => null,
        'notes' => null,
    ];
}

function upsert_payroll_period($conn, $year, $month, $status, $username = null, $notes = null, $branch_id = null)
{
    if ($branch_id === null) {
        $branch_id = payroll_context_branch_id();
    }
    $existing = get_payroll_period($conn, $year, $month, $branch_id);
    $approved_at = null;
    $locked_at = null;
    $approved_by = $existing['approved_by'] ?? null;
    $locked_by = $existing['locked_by'] ?? null;

    if ($status === 'approved' || $status === 'locked') {
        $approved_by = $username;
        $approved_at = date('Y-m-d H:i:s');
    }
    if ($status === 'locked') {
        $locked_by = $username;
        $locked_at = date('Y-m-d H:i:s');
    }
    if ($status === 'open') {
        $approved_by = null;
        $approved_at = null;
        $locked_by = null;
        $locked_at = null;
    }

    $stmt = $conn->prepare("
        INSERT INTO payroll_periods (branch_id, period_year, period_month, status, approved_by, approved_at, locked_by, locked_at, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            status = VALUES(status),
            approved_by = VALUES(approved_by),
            approved_at = VALUES(approved_at),
            locked_by = VALUES(locked_by),
            locked_at = VALUES(locked_at),
            notes = VALUES(notes)
    ");
    $stmt->bind_param('iiissssss', $branch_id, $year, $month, $status, $approved_by, $approved_at, $locked_by, $locked_at, $notes);
    $stmt->execute();
}

function is_payroll_period_locked($conn, $year, $month, $branch_id = null)
{
    $p = get_payroll_period($conn, $year, $month, $branch_id);
    return ($p['status'] ?? 'open') === 'locked';
}

function can_release_salary_slips_for_period($conn, $year, $month, $branch_id = null)
{
    $p = get_payroll_period($conn, $year, $month, $branch_id);
    $status = $p['status'] ?? 'open';

    return in_array($status, ['approved', 'locked'], true);
}

/** @deprecated Use can_release_salary_slips_for_period() */
function can_send_slips_for_period($conn, $year, $month)
{
    return can_release_salary_slips_for_period($conn, $year, $month);
}

function can_view_salary_slip_for_period($conn, $year, $month, $settings, $branch_id = null)
{
    if (!empty($settings['require_payroll_approval']) && (int) $settings['require_payroll_approval'] === 1) {
        if ($branch_id === null) {
            $branch_id = payroll_context_branch_id();
        }

        return can_release_salary_slips_for_period($conn, $year, $month, $branch_id);
    }

    return true;
}

function employee_salary_slip_is_available($conn, $employee, $year, $month, $settings)
{
    if ((float) ($employee['base_salary'] ?? 0) <= 0) {
        return false;
    }

    $stats = get_attendance_stats_extended($conn, $employee['emp_id'], $year, $month, $settings);
    if ($stats['total_records'] === 0) {
        return false;
    }

    $branch_id = (int) ($employee['branch_id'] ?? 1);

    return can_view_salary_slip_for_period($conn, $year, $month, $settings, $branch_id);
}

/**
 * Salary slip periods visible in the employee portal (no email send required).
 *
 * @return array<int, array{period_month:int, period_year:int, net_salary:float}>
 */
function get_employee_available_salary_slips($conn, $employee, $settings, $limit = 36)
{
    $limit = max(1, min(48, (int) $limit));
    $emp_id = $employee['emp_id'];
    $stmt = $conn->prepare('
        SELECT YEAR(attendance_date) AS period_year, MONTH(attendance_date) AS period_month
        FROM attendance
        WHERE emp_id = ?
        GROUP BY YEAR(attendance_date), MONTH(attendance_date)
        ORDER BY period_year DESC, period_month DESC
    ');
    $stmt->bind_param('s', $emp_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($period = $result->fetch_assoc()) {
        $year = (int) $period['period_year'];
        $month = (int) $period['period_month'];
        if (!employee_salary_slip_is_available($conn, $employee, $year, $month, $settings)) {
            continue;
        }
        $salary = calculate_employee_salary_full($conn, $employee, $year, $month, $settings);
        $rows[] = [
            'period_month' => $month,
            'period_year' => $year,
            'net_salary' => (float) $salary['net_salary'],
        ];
        if (count($rows) >= $limit) {
            break;
        }
    }

    return $rows;
}

function get_employee_available_salary_slips_by_id($conn, $emp_id, $settings, $limit = 36)
{
    $stmt = $conn->prepare('SELECT * FROM employees WHERE emp_id = ?');
    $stmt->bind_param('s', $emp_id);
    $stmt->execute();
    $employee = $stmt->get_result()->fetch_assoc();
    if (!$employee) {
        return [];
    }

    return get_employee_available_salary_slips($conn, $employee, $settings, $limit);
}

function payroll_period_status_label($status)
{
    return match ($status) {
        'review' => 'Under review',
        'approved' => 'Approved',
        'locked' => 'Locked',
        default => 'Open',
    };
}

/* ---------- Holidays ---------- */

function get_holidays_for_month($conn, $year, $month, $branch_id = null)
{
    if ($branch_id === null) {
        $branch_id = payroll_context_branch_id();
    }
    $start = sprintf('%d-%02d-01', $year, $month);
    $end = date('Y-m-t', strtotime($start));
    $stmt = $conn->prepare('SELECT * FROM holidays WHERE branch_id = ? AND calendar_date BETWEEN ? AND ? ORDER BY calendar_date');
    $stmt->bind_param('iss', $branch_id, $start, $end);
    $stmt->execute();
    $map = [];
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $map[$row['calendar_date']] = $row;
    }
    return $map;
}

function get_holidays_for_year($conn, $year, $branch_id = null)
{
    if ($branch_id === null) {
        $branch_id = payroll_context_branch_id();
    }
    $start = sprintf('%d-01-01', $year);
    $end = sprintf('%d-12-31', $year);
    $stmt = $conn->prepare('SELECT * FROM holidays WHERE branch_id = ? AND calendar_date BETWEEN ? AND ? ORDER BY calendar_date');
    $stmt->bind_param('iss', $branch_id, $start, $end);
    $stmt->execute();
    $rows = [];
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $rows[] = $row;
    }

    return $rows;
}

function get_holiday_dates_set($conn, $year, $month)
{
    return array_keys(get_holidays_for_month($conn, $year, $month));
}

/* ---------- Leave types ---------- */

function get_leave_types($conn)
{
    $types = [];
    $r = $conn->query('SELECT * FROM leave_types WHERE is_active = 1 ORDER BY code');
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $types[$row['code']] = $row;
        }
    }
    if ($types === []) {
        return get_default_leave_types_catalog();
    }
    return $types;
}

function get_default_leave_types_catalog()
{
    return [
        'PL' => ['code' => 'PL', 'name' => 'Privilege Leave', 'paid_credit' => '1.00', 'is_active' => '1'],
        'CL' => ['code' => 'CL', 'name' => 'Casual Leave', 'paid_credit' => '1.00', 'is_active' => '1'],
        'SL' => ['code' => 'SL', 'name' => 'Sick Leave', 'paid_credit' => '1.00', 'is_active' => '1'],
        'LOP' => ['code' => 'LOP', 'name' => 'Loss of Pay', 'paid_credit' => '0.00', 'is_active' => '1'],
    ];
}

function get_all_leave_types($conn)
{
    $types = [];
    $r = $conn->query('SELECT * FROM leave_types ORDER BY code');
    if ($r) {
        while ($row = $r->fetch_assoc()) {
            $types[$row['code']] = $row;
        }
    }
    return $types;
}

function format_leave_type_label(array $leave_type)
{
    return trim($leave_type['code'] . ' — ' . $leave_type['name']);
}

function get_leave_quota_setting_key($code)
{
    return 'leave_quota_' . strtolower($code);
}

function get_leave_types_with_yearly_quota($conn, $settings)
{
    $types = get_leave_types($conn);
    $result = [];
    foreach ($types as $code => $row) {
        $key = get_leave_quota_setting_key($code);
        if (array_key_exists($key, $settings)) {
            $result[$code] = $row;
        }
    }
    return $result;
}

function leave_type_codes_with_balance($conn, $settings)
{
    return array_keys(get_leave_types_with_yearly_quota($conn, $settings));
}

function save_leave_type($conn, $code, $name, $paid_credit, $is_active = 1)
{
    $code = strtoupper(trim($code));
    $name = trim($name);
    $paid_credit = max(0, min(1, (float) $paid_credit));
    $is_active = $is_active ? 1 : 0;

    if ($code === '' || !preg_match('/^[A-Z0-9]{1,10}$/', $code)) {
        return ['ok' => false, 'message' => 'Leave code must be 1–10 letters or numbers (e.g. PL, CL).'];
    }
    if ($name === '') {
        return ['ok' => false, 'message' => 'Full leave name is required.'];
    }

    $stmt = $conn->prepare('
        INSERT INTO leave_types (code, name, paid_credit, is_active)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE name = VALUES(name), paid_credit = VALUES(paid_credit), is_active = VALUES(is_active)
    ');
    $stmt->bind_param('ssdi', $code, $name, $paid_credit, $is_active);
    if (!$stmt->execute()) {
        return ['ok' => false, 'message' => 'Could not save leave type.'];
    }

    return ['ok' => true, 'message' => 'Leave type saved.'];
}

function get_leave_type_credit($conn, $code, $settings)
{
    if ($code === null || $code === '') {
        return get_leave_day_credit($settings);
    }
    $types = get_leave_types($conn);
    if (isset($types[$code])) {
        return (float) $types[$code]['paid_credit'];
    }
    return get_leave_day_credit($settings);
}

/* ---------- Employee payroll profile ---------- */

function get_employee_payroll_profile($conn, $emp_id)
{
    $stmt = $conn->prepare('SELECT * FROM employee_payroll_profiles WHERE emp_id = ?');
    $stmt->bind_param('s', $emp_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
}

function merge_settings_with_employee_profile($settings, $profile)
{
    if (!$profile || !(int) ($profile['use_custom'] ?? 0)) {
        return $settings;
    }
    $keys = ['pct_basic', 'pct_hra', 'pct_conveyance', 'pct_medical', 'pct_special', 'pf_percent', 'professional_tax', 'esi_percent', 'esi_gross_limit'];
    $merged = $settings;
    foreach ($keys as $key) {
        if (isset($profile[$key]) && $profile[$key] !== null && $profile[$key] !== '') {
            $merged[$key] = $profile[$key];
        }
    }
    return $merged;
}

/* ---------- Payroll adjustments ---------- */

function get_payroll_adjustments_for_period($conn, $emp_id, $year, $month)
{
    $stmt = $conn->prepare("
        SELECT * FROM payroll_adjustments
        WHERE emp_id = ? AND period_year = ? AND period_month = ?
        ORDER BY id
    ");
    $stmt->bind_param('sii', $emp_id, $year, $month);
    $stmt->execute();
    $rows = [];
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $rows[] = $row;
    }
    return $rows;
}

function sum_adjustments_by_kind(array $adjustments)
{
    $bonus = 0.0;
    $incentive = 0.0;
    $deduction = 0.0;
    foreach ($adjustments as $a) {
        $amt = (float) $a['amount'];
        if ($a['adj_type'] === 'bonus') {
            $bonus += $amt;
        } elseif ($a['adj_type'] === 'incentive') {
            $incentive += $amt;
        } else {
            $deduction += $amt;
        }
    }
    return ['bonus' => $bonus, 'incentive' => $incentive, 'deduction' => $deduction];
}

/* ---------- Extended attendance stats ---------- */

function get_attendance_stats_extended($conn, $emp_id, $year, $month, $settings = [])
{
    if ($settings !== []) {
        migrate_legacy_leave_balances_to_monthly($conn, $settings);
    }
    if (function_exists('accrue_monthly_leaves')) {
        accrue_monthly_leaves($conn, $settings, $year, $month);
    }

    $stmt = $conn->prepare("
        SELECT attendance_date, status, leave_type, overtime_hours FROM attendance
        WHERE emp_id = ? AND YEAR(attendance_date) = ? AND MONTH(attendance_date) = ?
    ");
    $stmt->bind_param('sii', $emp_id, $year, $month);
    $stmt->execute();
    $result = $stmt->get_result();

    $present_days = 0;
    $absent_days = 0;
    $half_days = 0;
    $leave_days = 0;
    $weekoff_days = 0;
    $leave_by_type = [];
    $other_days = 0;
    $overtime_hours = 0.0;
    $attendance_by_date = [];

    while ($row = $result->fetch_assoc()) {
        $attendance_by_date[$row['attendance_date'] ?? ''] = $row['status'];
        $bucket = normalize_status_bucket($row['status']);
        $overtime_hours += (float) ($row['overtime_hours'] ?? 0);
        switch ($bucket) {
            case 'present':
                $present_days++;
                break;
            case 'absent':
                $absent_days++;
                break;
            case 'half':
                $half_days++;
                break;
            case 'leave':
                $leave_days++;
                $lt = $row['leave_type'] ?: 'CL';
                $leave_by_type[$lt] = ($leave_by_type[$lt] ?? 0) + 1;
                break;
            case 'weekoff':
                $weekoff_days++;
                break;
            default:
                $other_days++;
        }
    }

    $roster_info = count_roster_weekoff_paid_credit($conn, $emp_id, $year, $month, $settings, $attendance_by_date);
    $roster_weekoff_days = (int) ($roster_info['weekoff_days'] ?? 0);
    $roster_weekoff_credit = (float) ($roster_info['weekoff_paid_credit'] ?? 0);

    $max_leaves = (int) ($settings['max_leaves_per_month'] ?? 4);
    $max_wos = (int) ($settings['max_wo_per_month'] ?? 4);

    $paid_leave_credit = 0.0;
    $leave_counted = 0;
    foreach ($leave_by_type as $code => $count) {
        $credit_per_day = get_leave_type_credit($conn, $code, $settings);
        for ($i=0; $i<$count; $i++) {
            if ($max_leaves === 0 || $leave_counted < $max_leaves) {
                $paid_leave_credit += $credit_per_day;
                $leave_counted++;
            } else {
                $absent_days++;
            }
        }
    }
    if ($leave_days > 0 && $paid_leave_credit === 0.0) {
        $actual_paid = ($max_leaves === 0) ? $leave_days : min($leave_days, $max_leaves);
        $paid_leave_credit = $actual_paid * get_leave_day_credit($settings);
        if ($max_leaves > 0 && $leave_days > $max_leaves) {
            $absent_days += ($leave_days - $max_leaves);
        }
    }

    $half_credit = get_half_day_credit($settings);
    $weekoff_credit = get_weekoff_day_credit($settings);
    
    $total_wos = $weekoff_days + $roster_weekoff_days;
    $total_wo_credit = ((float) $weekoff_days * $weekoff_credit) + $roster_weekoff_credit;
    
    if ($max_wos > 0 && $total_wos > $max_wos) {
        $excess_wos = $total_wos - $max_wos;
        $absent_days += $excess_wos;
        
        $max_wo_credit = $max_wos * $weekoff_credit;
        if ($total_wo_credit > $max_wo_credit) {
            $total_wo_credit = $max_wo_credit;
        }
    }

    $paid_days = round(
        (float) $present_days
        + (float) $half_days * $half_credit
        + $paid_leave_credit
        + $total_wo_credit,
        2
    );

    $late_punch_count = 0;
    $late_penalty_days = 0.0;
    if (($settings['punch_enabled'] ?? '1') === '1') {
        require_once __DIR__ . '/punch_helper.php';
        $late_punch_count = count_employee_late_punches_for_period($conn, $emp_id, $year, $month);
        $late_penalty_days = calculate_late_punch_penalty_days($late_punch_count, $settings);
        if ($late_penalty_days > 0) {
            $paid_days = max(0, round($paid_days - $late_penalty_days, 2));
        }
    }

    return [
        'present_days' => $present_days,
        'absent_days' => $absent_days,
        'half_days' => $half_days,
        'leave_days' => $leave_days,
        'weekoff_days' => $weekoff_days,
        'roster_weekoff_days' => $roster_weekoff_days,
        'leave_by_type' => $leave_by_type,
        'other_days' => $other_days,
        'total_records' => $present_days + $absent_days + $half_days + $leave_days + $weekoff_days + $other_days,
        'overtime_hours' => round($overtime_hours, 2),
        'paid_days' => $paid_days,
        'late_punch_count' => $late_punch_count,
        'late_penalty_days' => $late_penalty_days,
        'roster_weekoff_dates' => $roster_info['roster_dates'] ?? [],
    ];
}

/* ---------- Overtime pay ---------- */

function calculate_overtime_pay($employee, $stats, $settings)
{
    $hours = (float) ($stats['overtime_hours'] ?? 0);
    if ($hours <= 0) {
        return 0.0;
    }
    $working_days = get_working_days_per_month($settings);
    $base = (float) ($employee['base_salary'] ?? 0);
    $daily = $working_days > 0 ? $base / $working_days : 0;
    $hours_per_day = max(1, (float) ($settings['overtime_hours_per_day'] ?? 8));
    $multiplier = max(1, (float) ($settings['overtime_multiplier'] ?? 1.5));
    $hourly = $daily / $hours_per_day;
    return round($hours * $hourly * $multiplier, 2);
}

/* ---------- Full salary with extensions ---------- */

function calculate_employee_salary_full($conn, $employee, $year, $month, $settings)
{
    $profile = get_employee_payroll_profile($conn, $employee['emp_id']);
    $effective_settings = merge_settings_with_employee_profile($settings, $profile);
    $stats = get_attendance_stats_extended($conn, $employee['emp_id'], $year, $month, $effective_settings);

    $base_salary = (float) ($employee['base_salary'] ?? 0);
    $working_days = get_working_days_per_month($effective_settings);
    $daily_rate = $working_days > 0 ? $base_salary / $working_days : 0;
    $paid_days = (float) $stats['paid_days'];
    $earned_salary = round($daily_rate * $paid_days, 2);
    $ot_pay = calculate_overtime_pay($employee, $stats, $effective_settings);
    $adjustments = get_payroll_adjustments_for_period($conn, $employee['emp_id'], $year, $month);
    $adj_sums = sum_adjustments_by_kind($adjustments);

    $salary = [
        'base_salary' => $base_salary,
        'working_days' => $working_days,
        'daily_rate' => round($daily_rate, 2),
        'present_days' => (int) $stats['present_days'],
        'absent_days' => (int) $stats['absent_days'],
        'half_days' => (int) $stats['half_days'],
        'leave_days' => (int) $stats['leave_days'],
        'weekoff_days' => (int) ($stats['weekoff_days'] ?? 0),
        'roster_weekoff_days' => (int) ($stats['roster_weekoff_days'] ?? 0),
        'leave_by_type' => $stats['leave_by_type'],
        'paid_days' => $paid_days,
        'overtime_hours' => $stats['overtime_hours'],
        'overtime_pay' => $ot_pay,
        'earned_salary' => $earned_salary,
        'deduction' => round($daily_rate * (float) $stats['absent_days'], 2),
        'adjustments' => $adjustments,
        'bonus_total' => $adj_sums['bonus'],
        'incentive_total' => $adj_sums['incentive'],
        'extra_deductions' => $adj_sums['deduction'],
        'uses_custom_profile' => $profile && (int) ($profile['use_custom'] ?? 0),
    ];

    $period_gross_base = $earned_salary + $ot_pay + $adj_sums['bonus'] + $adj_sums['incentive'];
    $salary['earned_salary'] = $period_gross_base;

    $breakdown = build_salary_component_breakdown($salary, $effective_settings);

    if ($adj_sums['bonus'] > 0) {
        $breakdown['earnings'][] = [
            'id' => 'bonus', 'label' => 'Bonus', 'hint' => 'One-time', 'percent' => 0,
            'percent_label' => '—', 'monthly' => 0, 'period' => round($adj_sums['bonus'], 2),
        ];
        $breakdown['earnings_period_total'] += round($adj_sums['bonus'], 2);
    }
    if ($adj_sums['incentive'] > 0) {
        $breakdown['earnings'][] = [
            'id' => 'incentive', 'label' => 'Incentive', 'hint' => 'One-time', 'percent' => 0,
            'percent_label' => '—', 'monthly' => 0, 'period' => round($adj_sums['incentive'], 2),
        ];
        $breakdown['earnings_period_total'] += round($adj_sums['incentive'], 2);
    }
    if ($ot_pay > 0) {
        $breakdown['earnings'][] = [
            'id' => 'overtime', 'label' => 'Overtime pay', 'hint' => $stats['overtime_hours'] . ' hrs', 'percent' => 0,
            'percent_label' => '—', 'monthly' => 0, 'period' => $ot_pay,
        ];
        $breakdown['earnings_period_total'] += $ot_pay;
    }
    if ($adj_sums['deduction'] > 0) {
        $breakdown['deductions'][] = [
            'id' => 'adj_ded', 'label' => 'Other deductions', 'hint' => 'Adjustments', 'percent_label' => '—',
            'monthly' => 0, 'period' => round($adj_sums['deduction'], 2),
        ];
        $breakdown['deductions_period_total'] += round($adj_sums['deduction'], 2);
    }

    $breakdown['earnings_period_total'] = round($breakdown['earnings_period_total'], 2);
    $breakdown['deductions_period_total'] = round($breakdown['deductions_period_total'], 2);
    $breakdown['net_period'] = max(0, round($breakdown['earnings_period_total'] - $breakdown['deductions_period_total'], 2));

    $salary['breakdown'] = $breakdown;
    $salary['net_salary'] = $breakdown['net_period'];
    return $salary;
}

/* ---------- Employee portal slip helpers ---------- */

function employee_slip_already_sent($conn, $emp_id, $year, $month)
{
    require_once __DIR__ . '/settings_helper.php';
    $stmt = $conn->prepare('SELECT * FROM employees WHERE emp_id = ?');
    $stmt->bind_param('s', $emp_id);
    $stmt->execute();
    $employee = $stmt->get_result()->fetch_assoc();
    if (!$employee) {
        return false;
    }

    $settings = get_all_settings($conn);

    return employee_salary_slip_is_available($conn, $employee, $year, $month, $settings);
}

/* ---------- Leave Management ---------- */

function monthly_leave_accrual_from_yearly($yearly_quota)
{
    return round((float) $yearly_quota / 12, 2);
}

function migrate_legacy_leave_balances_to_monthly($conn, $settings)
{
    $flag = 'leave_monthly_accrual_migrated';
    $stmt = $conn->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
    $stmt->bind_param('s', $flag);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row && ($row['setting_value'] ?? '') === '1') {
        return;
    }

    $sl_monthly = monthly_leave_accrual_from_yearly($settings['leave_quota_sl'] ?? 9);
    $cl_monthly = monthly_leave_accrual_from_yearly($settings['leave_quota_cl'] ?? 8);
    $sl_yearly = (float) ($settings['leave_quota_sl'] ?? 9);
    $cl_yearly = (float) ($settings['leave_quota_cl'] ?? 8);

    $conn->query("UPDATE employee_leave_balances SET balance = {$sl_monthly} WHERE leave_type = 'SL' AND balance >= {$sl_yearly}");
    $conn->query("UPDATE employee_leave_balances SET balance = {$cl_monthly} WHERE leave_type = 'CL' AND balance >= {$cl_yearly}");

    $quota_types = get_leave_types_with_yearly_quota($conn, $settings);
    foreach ($quota_types as $leave_type => $row) {
        $leave_type_esc = $conn->real_escape_string($leave_type);
        $monthly = monthly_leave_accrual_from_yearly($settings[get_leave_quota_setting_key($leave_type)] ?? 0);
        $conn->query("
            INSERT INTO employee_leave_balances (emp_id, leave_type, balance)
            SELECT e.emp_id, '{$leave_type_esc}', {$monthly} FROM employees e
            WHERE e.is_active = 1
              AND NOT EXISTS (
                  SELECT 1 FROM employee_leave_balances b
                  WHERE b.emp_id = e.emp_id AND b.leave_type = '{$leave_type_esc}'
              )
        ");
    }

    require_once __DIR__ . '/settings_helper.php';
    set_setting($conn, $flag, '1');
}

function get_employee_leave_balances($conn, $emp_id, $settings)
{
    migrate_legacy_leave_balances_to_monthly($conn, $settings);
    accrue_monthly_leaves($conn, $settings, (int) date('Y'), (int) date('n'));

    $quota_codes = leave_type_codes_with_balance($conn, $settings);
    $balances = array_fill_keys($quota_codes, 0.00);
    $stmt = $conn->prepare("SELECT leave_type, balance FROM employee_leave_balances WHERE emp_id = ?");
    $stmt->bind_param('s', $emp_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $has_db_balance = [];
    while ($row = $res->fetch_assoc()) {
        if (array_key_exists($row['leave_type'], $balances)) {
            $balances[$row['leave_type']] = (float) $row['balance'];
        }
        $has_db_balance[$row['leave_type']] = true;
    }
    foreach ($quota_codes as $lt) {
        if (!isset($has_db_balance[$lt])) {
            $zero = 0.0;
            $stmt = $conn->prepare("INSERT IGNORE INTO employee_leave_balances (emp_id, leave_type, balance) VALUES (?, ?, ?)");
            $stmt->bind_param('ssd', $emp_id, $lt, $zero);
            $stmt->execute();
        }
    }
    return $balances;
}

function accrue_monthly_leaves($conn, $settings, $year, $month)
{
    // Ignore passed year/month. Use current system date.
    $current_year = (int) date('Y');
    $current_month = (int) date('n');

    $stmt = $conn->prepare("INSERT IGNORE INTO leave_accruals_log (period_year, period_month) VALUES (?, ?)");
    $stmt->bind_param('ii', $current_year, $current_month);
    $stmt->execute();

    // If affected_rows > 0, it means we just inserted it for the first time this month
    if ($stmt->affected_rows > 0) {
        $quota_types = get_leave_types_with_yearly_quota($conn, $settings);
        foreach ($quota_types as $leave_type => $row) {
            $monthly = monthly_leave_accrual_from_yearly($settings[get_leave_quota_setting_key($leave_type)] ?? 0);
            $leave_type_esc = $conn->real_escape_string($leave_type);
            $conn->query("
                INSERT INTO employee_leave_balances (emp_id, leave_type, balance)
                SELECT emp_id, '{$leave_type_esc}', {$monthly} FROM employees WHERE is_active = 1
                ON DUPLICATE KEY UPDATE balance = balance + {$monthly}
            ");
        }
    }
}
