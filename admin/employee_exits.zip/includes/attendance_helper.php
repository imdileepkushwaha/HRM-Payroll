<?php

function normalize_attendance_status_code($status)
{
    $s = strtolower(trim((string) $status));
    $s = preg_replace('/\s+/', ' ', $s);

    if (in_array($s, ['present', 'p'], true)) {
        return 'P';
    }
    if (in_array($s, ['absent', 'a'], true)) {
        return 'A';
    }
    if (in_array($s, ['half day', 'half-day', 'halfday', 'hd', 'h'], true)) {
        return 'HD';
    }
    if (in_array($s, ['week off', 'weekoff', 'week-off', 'wo', 'w/o', 'off'], true)) {
        return 'WO';
    }
    if (in_array($s, ['leave', 'l'], true)) {
        return 'L';
    }
    if (str_starts_with($s, 'half')) {
        return 'HD';
    }

    $upper = strtoupper($s);
    if ($upper === 'HD') {
        return 'HD';
    }
    if (in_array($upper, ['P', 'A', 'L'], true)) {
        return $upper;
    }

    return '';
}

function attendance_code_css_class($code)
{
    return match ($code) {
        'P' => 'att-code-p',
        'A' => 'att-code-a',
        'HD' => 'att-code-hd',
        'WO' => 'att-code-wo',
        'L' => 'att-code-l',
        default => 'att-code-unknown',
    };
}

function attendance_code_label($code)
{
    return match ($code) {
        'P' => 'Present',
        'A' => 'Absent',
        'HD' => 'Half day',
        'WO' => 'Week off',
        'L' => 'Leave',
        default => 'Other',
    };
}

function attendance_leave_display_code(array $detail = null)
{
    if ($detail && !empty($detail['leave_type'])) {
        return strtoupper((string) $detail['leave_type']);
    }
    return 'L';
}

function build_attendance_date_map($result)
{
    $map = [];
    if (!$result) {
        return $map;
    }
    while ($row = $result->fetch_assoc()) {
        $map[$row['attendance_date']] = $row['status'];
    }
    return $map;
}

function count_attendance_codes(array $date_map)
{
    $counts = ['P' => 0, 'A' => 0, 'HD' => 0, 'WO' => 0, 'L' => 0, 'other' => 0];
    foreach ($date_map as $status) {
        $code = normalize_attendance_status_code($status);
        if (isset($counts[$code])) {
            $counts[$code]++;
        } else {
            $counts['other']++;
        }
    }
    return $counts;
}

/**
 * Count codes the same way the attendance calendar displays them
 * (includes roster weekoffs when no attendance record overrides the day).
 */
function count_calendar_display_codes($year, $month, array $attendance_by_date, array $weekoff_dates = [], array $holidays_map = [], array $punch_half_day_dates = [])
{
    $counts = ['P' => 0, 'A' => 0, 'HD' => 0, 'WO' => 0, 'L' => 0, 'other' => 0];
    $days_in_month = (int) date('t', mktime(0, 0, 0, $month, 1, $year));
    $punch_half_day_lookup = array_fill_keys($punch_half_day_dates, true);

    for ($day = 1; $day <= $days_in_month; $day++) {
        $date_key = sprintf('%d-%02d-%02d', $year, $month, $day);
        $raw_status = $attendance_by_date[$date_key] ?? null;
        $code = $raw_status !== null ? normalize_attendance_status_code($raw_status) : '';
        $has_record = $raw_status !== null;
        $is_holiday = isset($holidays_map[$date_key]);
        $is_roster_wo = in_array($date_key, $weekoff_dates, true);
        $is_punch_half_day = isset($punch_half_day_lookup[$date_key]);

        if ($is_holiday && !$has_record && !$is_punch_half_day) {
            continue;
        }

        if ($is_punch_half_day && (!$has_record || $code === 'P')) {
            $counts['HD']++;
            continue;
        }

        if ($has_record && $code !== '') {
            if (isset($counts[$code])) {
                $counts[$code]++;
            } else {
                $counts['other']++;
            }
        } elseif ($is_roster_wo) {
            $counts['WO']++;
        }
    }

    return $counts;
}

function employee_view_period_url($emp_id, $month, $year)
{
    return 'employee_view.php?emp_id=' . urlencode($emp_id)
        . '&month=' . (int) $month
        . '&year=' . (int) $year;
}

function get_adjacent_period($month, $year, $delta_months)
{
    $ts = mktime(0, 0, 0, (int) $month + (int) $delta_months, 1, (int) $year);
    return [(int) date('n', $ts), (int) date('Y', $ts)];
}

function render_attendance_calendar($year, $month, array $attendance_by_date, $today_day = 0, array $holidays_map = [], $editable = false, array $attendance_detail = [], array $weekoff_dates = [], array $punch_half_day_dates = [])
{
    $days_in_month = (int) date('t', mktime(0, 0, 0, $month, 1, $year));
    $calendar_start_dow = (int) date('w', mktime(0, 0, 0, $month, 1, $year));
    $weekdays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    $punch_half_day_lookup = array_fill_keys($punch_half_day_dates, true);

    ob_start();
    ?>
    <div class="att-calendar att-calendar-compact">
        <div class="att-cal-weekdays">
            <?php foreach ($weekdays as $wd): ?>
                <span><?php echo $wd; ?></span>
            <?php endforeach; ?>
        </div>
        <div class="att-cal-grid">
            <?php for ($i = 0; $i < $calendar_start_dow; $i++): ?>
                <div class="att-cal-cell att-cal-cell-empty" aria-hidden="true"></div>
            <?php endfor; ?>
            <?php for ($day = 1; $day <= $days_in_month; $day++): ?>
                <?php
                $date_key = sprintf('%d-%02d-%02d', $year, $month, $day);
                $raw_status = $attendance_by_date[$date_key] ?? null;
                $detail = $attendance_detail[$date_key] ?? null;
                $code = $raw_status !== null ? normalize_attendance_status_code($raw_status) : '';
                $display_code = $code;
                if ($code === 'L' && $detail) {
                    $display_code = attendance_leave_display_code($detail);
                }
                $has_record = $raw_status !== null;
                $is_holiday = isset($holidays_map[$date_key]);
                $is_roster_wo = in_array($date_key, $weekoff_dates, true);
                $is_punch_half_day = isset($punch_half_day_lookup[$date_key]);
                $show_punch_half_day = $is_punch_half_day && (!$has_record || $code === 'P');
                if ($show_punch_half_day) {
                    $code = 'HD';
                    $display_code = 'HD';
                    $has_record = true;
                }
                $is_today = ($today_day > 0 && $day === $today_day);
                $cell_class = 'att-cal-cell';
                if ($editable) {
                    $cell_class .= ' att-cal-cell-clickable';
                }
                if ($is_today) {
                    $cell_class .= ' att-cal-today';
                }
                if ($is_holiday) {
                    $cell_class .= ' att-cal-holiday';
                }
                if ($is_roster_wo && !$has_record) {
                    $cell_class .= ' att-cal-roster-wo';
                }
                if (!$has_record) {
                    $cell_class .= ' att-cal-no-record';
                }
                $title = $show_punch_half_day
                    ? $date_key . ' — Half day (late in & early out)'
                    : ($has_record
                        ? $date_key . ' — ' . attendance_code_label($code)
                            . ($code === 'L' && !empty($detail['leave_type']) ? ' (' . $detail['leave_type'] . ')' : '')
                            . ($raw_status !== null ? ' (' . $raw_status . ')' : '')
                        : ($is_holiday
                            ? $date_key . ' — ' . ($holidays_map[$date_key]['name'] ?? 'Holiday')
                            : ($is_roster_wo ? $date_key . ' — Week off (roster)' : $date_key . ' — No record')));
                $data_attrs = '';
                if ($editable) {
                    $leave_type = $detail['leave_type'] ?? 'CL';
                    $ot_hrs = $detail['overtime_hours'] ?? '0';
                    $data_attrs = ' data-date="' . htmlspecialchars($date_key) . '"'
                        . ' data-status="' . htmlspecialchars($raw_status ?? 'Present') . '"'
                        . ' data-leave-type="' . htmlspecialchars($leave_type) . '"'
                        . ' data-overtime="' . htmlspecialchars((string) $ot_hrs) . '"'
                        . ' role="button" tabindex="0"';
                }
                ?>
                <div class="<?php echo $cell_class; ?>" title="<?php echo htmlspecialchars($title); ?>"<?php echo $data_attrs; ?>>
                    <span class="att-cal-day-num"><?php echo $day; ?></span>
                    <?php if ($is_holiday && !$has_record): ?>
                        <span class="att-cal-code att-cal-holiday-code">HO</span>
                    <?php elseif ($has_record && $code !== ''): ?>
                        <span class="att-cal-code <?php echo attendance_code_css_class($code); ?><?php echo $code === 'L' ? ' att-cal-code-leave' : ''; ?>"><?php echo htmlspecialchars($display_code); ?></span>
                    <?php elseif ($is_roster_wo): ?>
                        <span class="att-cal-code att-code-wo">WO</span>
                    <?php elseif ($has_record): ?>
                        <span class="att-cal-code att-code-unknown" title="<?php echo htmlspecialchars($raw_status); ?>">?</span>
                    <?php else: ?>
                        <span class="att-cal-code att-cal-dash">—</span>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function clear_branch_attendance_for_month($conn, int $branch_id, int $year, int $month): int
{
    require_once __DIR__ . '/weekoff_roster_helper.php';
    [$start, $end] = get_month_date_bounds($year, $month);
    $stmt = $conn->prepare('
        DELETE a FROM attendance a
        INNER JOIN employees e ON e.emp_id = a.emp_id
        WHERE e.branch_id = ? AND a.attendance_date BETWEEN ? AND ?
    ');
    $stmt->bind_param('iss', $branch_id, $start, $end);
    $stmt->execute();

    return (int) $stmt->affected_rows;
}

function restore_branch_attendance_baseline_for_month($conn, int $branch_id, int $year, int $month): array
{
    require_once __DIR__ . '/weekoff_roster_helper.php';
    require_once __DIR__ . '/employee_portal_helper.php';

    $deleted = clear_branch_attendance_for_month($conn, $branch_id, $year, $month);
    $wo_restored = 0;
    $leave_restored = 0;

    $roster_map = get_branch_weekoff_roster_map($conn, $year, $month, $branch_id);
    foreach ($roster_map as $emp_id => $dates) {
        sync_weekoff_roster_attendance($conn, $emp_id, $dates, []);
        $wo_restored += count($dates);
    }

    $emp_stmt = $conn->prepare('SELECT emp_id FROM employees WHERE branch_id = ? AND is_active = 1');
    $emp_stmt->bind_param('i', $branch_id);
    $emp_stmt->execute();
    $employees = $emp_stmt->get_result();
    while ($emp = $employees->fetch_assoc()) {
        $leave_restored += sync_approved_leave_attendance_for_period($conn, $emp['emp_id'], $year, $month);
    }

    return [
        'deleted' => $deleted,
        'wo_restored' => $wo_restored,
        'leave_restored' => $leave_restored,
    ];
}
