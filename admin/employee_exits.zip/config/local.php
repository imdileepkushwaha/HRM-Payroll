<?php
/**
 * Local XAMPP — auto-loaded on localhost / LAN only.
 */

define('PAYROLL_MYSQL_HOST', '127.0.0.1');
define('PAYROLL_MYSQL_DATABASE', 'hrm_db');
define('PAYROLL_MYSQL_USER', 'root');
define('PAYROLL_MYSQL_PASS', '');

define('PAYROLL_ALLOW_SETUP_TOOLS', true);
