<?php
/**
 * Live server — auto-loaded when site is not opened via localhost/LAN.
 * Upload this file to the server (same path: admin/config/production.php).
 */

define('PAYROLL_MYSQL_HOST', 'localhost');
define('PAYROLL_MYSQL_DATABASE', 'payroll_db');
define('PAYROLL_MYSQL_USER', 'payroll_db');
define('PAYROLL_MYSQL_PASS', 'OfWwvvtwsF66%*3h');

define('PAYROLL_ALLOW_SETUP_TOOLS', false);
